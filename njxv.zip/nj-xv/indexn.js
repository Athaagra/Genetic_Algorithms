const request = require("request-promise");
const regularRequest = require("request");
const fs = require("fs");
const axios = require('axios');
const cheerio = require("cheerio"); 
const Nightmare = require("nightmare");
const nightmare = Nightmare({show:false});
const os =require("os");
const http = require("http");
const https = require("https");
const download = require('image-downloader');
const createStreamableFile = require('node-streamable-file');
const open = require('node:fs/promises');
const basename = require('node:path');
const cron = require("node-cron");
const FileDownload = require("crawlee");
const saveAs = require("file-saver");
var LocalStorage = require('node-localstorage').LocalStorage,
localStorage = new LocalStorage('./scratch');
//require('child_process').exec('start https://beeg.com');

const puppeteer = require('puppeteer');




let browser;
async function scrapeTitlesRanksAndRatings() {
    const browser = await puppeteer.launch({ headless: true }); // Launch the browser
    const page = await browser.newPage(); // Open a new page
	page.setDefaultNavigationTimeout(0);
    // Navigate to the target website
    await page.goto('https://beeg.com/', {
            waitUntil: 'networkidle2', // Wait until the network is idle
    });
	const html = await page.content();
	const $ = cheerio.load(html); 
	//const $ = await cheerio.load(result);
	console.log('This is the page',$.html);
	const movies = $("main.v-main > div.index-page > div.index-page__content > div.core-page > div.core-page__inner > div.core-page__content > div.infinite-scroll > div.tw-relative > div.core-page__unit-column").map((i, element) => {
		const title = $(element).find("div.tw-relative > div.UnitFrame > div.UnitFrame__media > a.tw-absolute > img.tw-rounded-12").attr('alt');
		const user_id =1;
		const url =$(element).find("div.tw-relative > div.UnitFrame > div.UnitFrame__media > a").attr('href');
		const body =$(element).find("div.tw-relative > div.UnitFrame > a").attr('href');
		const posteras=$(element).find("div.tw-relative > div.UnitFrame > div.UnitFrame__media > a.tw-absolute > img.tw-rounded-12").attr('src');
		const urla = url;
		console.log('This is the urla',urla);
		//console.log(title,user_id,url,body,posteras);
		//page.goto(url, {
         //   waitUntil: 'networkidle2', // Wait until the network is idle
		//});
		//const htmls = page.content();
		return {user_id,title,body,url,posteras};
	}).get();
	//console.log(movies);
	return movies;
}

const loadPage = async (mov)=>{
		await page.goto(mov, {
						waitUntil: 'networkidle2', // Wait until the network is idle
		});
		//const html = await page.content();
		//console.log('This is the page content',html);
		//const $ = await cheerio.load(html);
		//const categorics = $(" body > div#app > div.v-application.v-layout.v-layout--full-height.v-locale--is-ltr > div.v-application__wrap > div.default-layout > main.v-main > div.index-page > div.index-page__content > div.core-page.content-container > div.core-page__inner > div.tw-pb-6.not-mobile-only:tw-absolute.not-mobile-only:tw-z-[1].not-mobile-only:tw-right-0.not-mobile-only:tw-left-0 > div >div.tw-mt-3 > div.tw-flex.tw-items-center.tw--mb-[10px] > div.tw-mask-image-[linear-gradient(to_left,transparent_0,_#000_40px)].tw-overflow-hidden.tw-grow.tw-pl-3.sm:tw-pl-0 > div.tw-text-body.tw-whitespace-nowrap.tw-text-body-16").text();
		//return $;//categorics;
		//} catch (err) {
		//	console.log(err);
		//}
};


async function scrapePosterUrl(movies){
	const moviesWithPosterUrls = await Promise.all(
		movies.map(async movie => {
		try {
			//console.log('This is the movie url',movie.url);
			//const html = await request.get(movie.url);
			// Open a new page
		// Navigate to the target website
			//console.log('This is the movie url',$);
			//const html = await nw(movie.url);
			console.log('this is category',html);
			/*const $ = movie.urla;
			console.log('This is cherrio',movie.urla);
			const categorics = $(" body > div#app > div.v-application.v-layout.v-layout--full-height.v-locale--is-ltr > div.v-application__wrap > div.default-layout > main.v-main > div.index-page > div.index-page__content > div.core-page.content-container > div.core-page__inner > div.tw-pb-6.not-mobile-only:tw-absolute.not-mobile-only:tw-z-[1].not-mobile-only:tw-right-0.not-mobile-only:tw-left-0 > div >div.tw-mt-3 > div.tw-flex.tw-items-center.tw--mb-[10px] > div.tw-mask-image-[linear-gradient(to_left,transparent_0,_#000_40px)].tw-overflow-hidden.tw-grow.tw-pl-3.sm:tw-pl-0 > div.tw-text-body.tw-whitespace-nowrap.tw-text-body-16").text();
			console.log('This is CATEGORICS ',categorics);
			const concategories = categorics.replace(/\s+/g, "");
			movie.category_id = concategories.toUpperCase(); 
			console.log(categorics);
			movie.imgUrl = '';
			movie.imgName = categorics.match(/[A-Z]/g).join(''); 
			//movie.posterUrl = $("#EPvideo").attr('poster');
			movie.pornstar=$("#app > div.v-application > div.v-application__wrap > div.default-layout > header.tw-left-0 > main.v-main > div.index-page > div.tw-opacity-0 > div.filter-navigation > div.index-page__content > div.core-page > div.core-page__inner > div.tw-pb-6 > div.tw-mt-3 > div.tw-relative > div.tw-overflow-scroll > div.tw-flex > div.tw-mr-12 > div.Details__Train > div.tw-flex > a.tw-relative ").attr('href');
			movie.industry = $("#app > div.v-application > div.v-application__wrap > div.default-layout > header.tw-left-0 > main.v-main > div.index-page > div.tw-opacity-0 > div.filter-navigation > div.index-page__content > div.core-page > div.core-page__inner > div.tw-pb-6 > div.tw-mt-3 > div.tw-relative > div.tw-overflow-scroll > div.tw-flex > div.tw-mr-12 > div.Details__Train > div.tw-flex > div.Details__Train__Item__Info > div.Details__Train__Item__Info__wrapper > a.tw-text-title-16").attr('text');
			//movie.video_url ="https://www.eporner.com/embed/" + emb;*/
			return movie;
			//}
		} catch (err) {
			console.log(err);
		}
	}));
	return moviesWithPosterUrls;
}

async function savePosterasImageToDisk(movie,i){
	console.log('This the gifs',i);
	try {
		const videoUrl = movie.posteras; // The video URL passed as a query parameter
		const response = await axios({
			url: videoUrl,
			method: 'GET',
			responseType: 'stream',
		});
		await response.data.pipe(fs.createWriteStream(__dirname+'/gifs/'+movie.imgGifs,{flags: 'w', encoding: 'utf-8',mode: 0666}));
  } catch (error) {
    //console.error('Error downloading the video:', error);
	//movies[i] = undefined;
	return i;
    //res.status(500).json({ success: false, error: 'Failed to download the video.' });
  }
 
}



async function main() {
	 try {
		//await scrapers();
		let movies = await scrapeTitlesRanksAndRatings();
		movies = await scrapePosterUrl(movies);
		console.log(movies);
		movies = await scrapePosterImageUrl(movies);
	}
  catch (error) {
    console.error(error);
  }
}

main();