#! /bin/sh
for x in $(seq 1 50000); do
	for i in $(seq 1 5000000); do
		if [[ $i -eq 5000000 ]]; then
			node indexq.js
		fi
	done
done